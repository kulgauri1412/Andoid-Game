package com.example.demo3

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.Log

class Circle (var startX: Float, var startY: Float, var radius: Float) {
    var paint: Paint

    init {
        paint = Paint()
        paint.color = Color.WHITE
        paint.style = Paint.Style.FILL
        paint.strokeWidth = 2f
    }

    fun drawOn(canvas: Canvas) {
        Log.i("CircleView","Circle view")
        canvas.drawCircle(startX, startY, radius, paint)
    }


}
