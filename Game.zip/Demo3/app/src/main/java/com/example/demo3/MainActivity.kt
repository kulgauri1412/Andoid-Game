package com.example.demo3

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

lateinit var start: Button
lateinit var pause_reset: Button
lateinit var score: TextView
lateinit var lives: TextView
var incraseScore: Int = 0
var mode: Int = 0
var changeClick = 0
var startButton: Int = 0

class MainActivity : AppCompatActivity() {
    public val Game_Tag = "Gametag"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        score = findViewById(R.id.score)
        start = findViewById(R.id.start)
        lives = findViewById(R.id.lives)
        pause_reset = findViewById(R.id.pause_reset)

    }

    fun getMode(): Int {
        return mode
    }

    fun getStart(): Int {
        return startButton
    }


}


