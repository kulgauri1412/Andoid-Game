package com.example.demo3

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*


/**
 * TODO: document your custom view class.
 */
class MyView : View, View.OnTouchListener {

    constructor(context: Context) : super(context) {}
    constructor(context: Context, attributes: AttributeSet) : super(context, attributes) {
        setOnTouchListener(this)

    }

    companion object {
        val black: Paint = Paint()
        val blackCircle = Paint()
        /* val circle1 = Paint()
         var circle2 = Paint()*/
    }

    init {

        black.color = Color.BLACK
        black.strokeWidth = 12f
        blackCircle.color = Color.BLACK
        blackCircle.isFilterBitmap = true
        blackCircle.isAntiAlias = true
    }

    val Game_Tag = "GameTag"
    //Black Circle
    private var startX: Float = 0f
    private var startY: Float = 0f
    private var blackRadious = 70f

    //White Circle
    private var circleX: Float = 550f
    private var circleY: Float = 1200f
    //private var radious : Float = 30f
    private var midX = 0f
    private var midY = 0f
    private var r1: Float = 0.toFloat()
    var handle = Handler()
    var isGrow = false

    private val circleSet = ArrayList<Circle>()
    private var radius: Float = 50.toFloat()
    private val circlepaint = Paint()
    var isInMotion = true
    var screenWidth: Int = 0
    var screenHeight: Int = 0

    // Used for formula
    var dx: Float = 0.0f
    var dy: Float = 0.0f
    var x1: Float = 0.0f
    var y1: Float = 0.0f

    var Lives: Int = 3
    var speed: Float = 2f
    var increaseSpeed: Double = 1.25
    var changePause = 0

    var finalScore = 0
    var distance: Double = 0.0
    var combineRadious: Float = 0f
    var iteration = -1
    var detectionMode = 1

    fun setMode() {

        val mainActivity = MainActivity()
        var mode = mainActivity.getMode()
    }


    fun setStart() {

        val mainActivity = MainActivity()
        var startButton = mainActivity.getStart()
    }


    override fun onTouch(arg0: View, event: MotionEvent): Boolean {

        setMode()
        Log.i(Game_Tag, "Button mode : $mode")
        val action = event.action
        val actionCode = action and MotionEvent.ACTION_MASK


        if (event.pointerCount > 1) {
            MotionEvent.ACTION_POINTER_DOWN
            return true

        }

        when (actionCode) {
            MotionEvent.ACTION_DOWN -> return handleActionDown(event)
            MotionEvent.ACTION_MOVE -> return handleActionMove(event)
            MotionEvent.ACTION_UP -> return handleActionUp(event)
            else -> return false
        }
    }


    private fun handleActionMove(event: MotionEvent): Boolean {

        if (mode == 0) {
            isGrow = true
            Log.i(Game_Tag, "Inside draw circle : $mode")
            circlepaint.setStyle(Paint.Style.FILL)
            circlepaint.setStrokeWidth(4f)
            circlepaint.setColor(Color.WHITE)
            midX = event.x
            midY = event.y
                // r1 = Math.sqrt(Math.pow((startX - midX).toDouble(), 2.0) + Math.pow((startY - midY).toDouble(), 2.0))
                .toFloat()
            invalidate()

        } else if (mode == 1 || mode == 3) {

            y1 = width.toFloat()
            x1 = event.getX()
            var middlePoint = width / 2

            if (x1 > middlePoint) {


                circleX = circleX + 35

                if (circleX > 995) {
                    circleX = 995.toFloat()
                }
                Log.i(Game_Tag, "Center Right side : $circleX")
                invalidate()
            } else {
                circleX = circleX - 35

                if (circleX < 70f) {
                    circleX = 70.toFloat()
                }
                Log.i(Game_Tag, "Center Left side : $circleX")
                invalidate()
            }

            Log.i(Game_Tag, "Handle action game started   $circleX")

        } else if (mode == 2 || mode == 4) {

            Log.i(Game_Tag, "Handle action game started")

            invalidate()

        }
        return true

    }


    private fun handleActionDown(event: MotionEvent): Boolean {
        if (mode == 0) {
            isGrow = true
            Log.e(Game_Tag, "Flag down : $isGrow")
            startX = event.x
            startY = event.y


            Log.i(Game_Tag, "Call : Down")
            Log.i(Game_Tag, "Call : Radius : $radius")


        } else if (mode == 1 || mode == 3) {

            y1 = width.toFloat()
            x1 = event.getX()
            var middlePoint = width / 2


            if (x1 > middlePoint) {


                circleX = circleX + 35

                if (circleX > 995) {
                    circleX = 995.toFloat()
                }
                Log.i(Game_Tag, "Center Right side : $circleX")
                invalidate()
            } else {
                circleX = circleX - 35

                if (circleX < 70f) {
                    circleX = 70.toFloat()
                }
                Log.i(Game_Tag, "Center Left side : $circleX")
                invalidate()
            }

        }
        return true
    }

    fun growCircle() {
        circlepaint.setStyle(Paint.Style.FILL)
        circlepaint.setStrokeWidth(4f)
        circlepaint.setColor(Color.WHITE)
        r1 = radius
        radius++
        Log.e(Game_Tag, "In grow circle :$radius")
        invalidate()
    }

    private fun handleActionUp(event: MotionEvent): Boolean {

        if (mode == 0) {

            isGrow = false
            Log.i(Game_Tag, "Check radius: $isGrow ,$radius ")
            circleSet.add(Circle(startX, startY, radius))
            radius = 50f

        }

        return true
    }


    override fun onDraw(canvas: Canvas) {

        canvas.drawColor(Color.LTGRAY)
        canvas.drawCircle(circleX, circleY, blackRadious, blackCircle)

        if (isGrow == true) {
            handle.postDelayed({ growCircle() }, 10)
            canvas.drawCircle(startX, startY, r1, circlepaint)
        }

        for (circle in circleSet) {
            Log.i(Game_Tag, "Inside for")
            circle.drawOn(canvas)
        }

        (context as MainActivity).start.setOnClickListener {

            startGame()
        }

        (context as MainActivity).pause_reset.setOnClickListener {

            pauseRestart()
        }

        if (startButton == 1) {
            Log.i(Game_Tag, "Inside draw call moving")
            moveCircle()

        }
        if (startButton == 0) {
            isInMotion = false
        }


    }

    fun startGame() {

        if (changeClick == 0) {
            mode = 1
            startButton = 1
            detectionMode = 1
            changeClick++
            pause_reset.isEnabled = true
            start.text = "End"
            moveCircle()

        } else if (changeClick == 1) {
            mode = 4
            Log.i(Game_Tag, "$mode $changeClick")
            changeClick++
            start.text = "New"
            pause_reset.isEnabled = false
            startButton = 0
        } else if (changeClick == 2) {
            mode = 0
            changeClick = 0
            Log.i(Game_Tag, "$mode $changeClick")
            startButton = 0
            (context as MainActivity).recreate()
        } else
            Log.i(Game_Tag, "Not working anything")

    }

    fun pauseRestart() {

        if (changePause == 0) {
            pause_reset.text = "Resume"
            startButton = 0
            changePause++
            mode = 2

        } else {
            mode = 3
            changePause = 0
            startButton = 1
            pause_reset.text = "Pause"

            moveCircle()
        }

        Log.i(Game_Tag, "Reset : $startButton")

    }

    fun moveCircle() {
        Log.i(Game_Tag, "Start Game")
        val allCircle = circleSet.iterator()
        var total = circleSet.size
        var checkLoop: Int = 0
        screenHeight = height
        Log.i(Game_Tag, "ScreenHeight: $screenHeight")

        while (allCircle.hasNext()) {
            val getWhiteCircle = allCircle.next()
            Log.i(Game_Tag, "Circle get something : $getWhiteCircle")
            if (getWhiteCircle.startY <= screenHeight) {
                if (checkLoop == 1) {

                    getWhiteCircle.startX = getWhiteCircle.startX
                    getWhiteCircle.startY = getWhiteCircle.startY + speed

                    dx = circleX - getWhiteCircle.startX
                    dy = circleY - getWhiteCircle.startY

                    distance = Math.sqrt((dx * dx + dy * dy).toDouble())
                    combineRadious = blackRadious + getWhiteCircle.radius

                    if (Lives == 0) {
                        Toast.makeText(context, "Game Over", Toast.LENGTH_SHORT).show()
                        mode = 0
                        startButton = 0
                        changeClick = 0
                        (context as MainActivity).recreate()
                    }
                    if (distance < combineRadious) {
                        Log.i(Game_Tag, "Detect collision")
                        Lives--
                       // speed = 2f
                        (context as MainActivity).lives.text = "Lives: " + " $Lives"
                        getWhiteCircle.startY = screenHeight - getWhiteCircle.startY
                        Toast.makeText(context, "Collision Detected $Lives", Toast.LENGTH_SHORT).show()
                    }

                    Log.i(Game_Tag, "increase speed by 25%)")
                } else {

                    getWhiteCircle.startX = getWhiteCircle.startX
                    getWhiteCircle.startY = getWhiteCircle.startY + speed

                    dx = circleX - getWhiteCircle.startX
                    dy = circleY - getWhiteCircle.startY

                    distance = Math.sqrt((dx * dx + dy * dy).toDouble())
                    combineRadious = blackRadious + getWhiteCircle.radius

                    if (Lives == 0) {
                        Toast.makeText(context, "Game Over", Toast.LENGTH_SHORT).show()
                        mode = 0
                        startButton = 0
                        changeClick = 0
                        (context as MainActivity).recreate()
                    }
                    if (distance < combineRadious) {
                        Log.i(Game_Tag, "Detect collision")
                        Lives--
                        //speed = 2f
                        (context as MainActivity).lives.text = "Lives: " + " $Lives"
                        getWhiteCircle.startY = screenHeight - getWhiteCircle.startY
                        Toast.makeText(context, "Collision Detected $Lives", Toast.LENGTH_SHORT).show()

                    }


                }

            } else if (getWhiteCircle.startY > screenHeight) {
                checkLoop = 1
                iteration++

                var countCircle = iteration / total
                var currentIteration = countCircle + 1
                var scoreMult = currentIteration * 1

                finalScore = finalScore + scoreMult

                (context as MainActivity).score.text = "Score :" + " $finalScore"


                if (speed <= 16) {

                    speed = ((speed * increaseSpeed).toFloat())
                    Log.i(Game_Tag, "Speed : $speed")

                    getWhiteCircle.startX = getWhiteCircle.startX
                    getWhiteCircle.startY = screenHeight - getWhiteCircle.startY
                } else if (speed > 17) {
                    speed = 20f
                    // Toast.makeText(context,"Maximum speed",Toast.LENGTH_SHORT).show()

                    getWhiteCircle.startX = getWhiteCircle.startX
                    getWhiteCircle.startY = screenHeight - getWhiteCircle.startY
                }


            }

            /*if (isInMotion)
                getWhiteCircle.postDelayed({ moveCircle() }, 1)*/

            Log.i(Game_Tag, "Check: ")

            invalidate()
        }
    }


}

private fun Circle.postDelayed(function: () -> Unit, i: Int) {

}


